<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
404