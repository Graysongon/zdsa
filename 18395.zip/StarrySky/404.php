<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('public/header.php');


 ?>
    

        <style>.t-404 span{margin-right:10px}</style>
        <section>
            <div class="tin-user-autograph t-404" style="margin-top: 250px;">
               
                <p><span style="font-size:55px;color: #ff009d;">4</span><span style="font-size:35px">0</span><span style="font-size:45px;color: #ffde4f;">4</span></p>
            </div>
        </section>
        





<?php $this->need('public/footer.php'); ?>
