// 支持全局代理路径配置 /socks5:// 和 /http://
let 哎呀呀这是我的TJ密钥 = "aaeaa2f3-1a94-46fb-8438-23f46052a0fa"; // trojan使用的密码，不一定要UUID，任意字符都可以，只是UUID理论上破解不了

// SHA224哈希函数实现
function sha224Hash(message) {
    const kConstants = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be,
        0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa,
        0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85,
        0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
        0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ];
    const toUtf8 = (str) => {return unescape(encodeURIComponent(str))};
    const bytesToHex = (byteArray) => {
        let hexString = '';
        for (let i = 0; i < byteArray.length; i++) {
            hexString += ((byteArray[i] >>> 4) & 0x0F).toString(16);
            hexString += (byteArray[i] & 0x0F).toString(16);
        }
        return hexString;
    };
    const computeHash = (inputStr) => {
        let hState = [
            0xc1059ed8, 0x367cd507, 0x3070dd17, 0xf70e5939,
            0xffc00b31, 0x68581511, 0x64f98fa7, 0xbefa4fa4
        ];
        const messageBitLength = inputStr.length * 8;
        inputStr += String.fromCharCode(0x80);
        while ((inputStr.length * 8) % 512 !== 448) {inputStr += String.fromCharCode(0)}
        const highBits = Math.floor(messageBitLength / 0x100000000);
        const lowBits = messageBitLength & 0xFFFFFFFF;
        inputStr += String.fromCharCode(
            (highBits >>> 24) & 0xFF, (highBits >>> 16) & 0xFF, (highBits >>> 8) & 0xFF, highBits & 0xFF,
            (lowBits >>> 24) & 0xFF, (lowBits >>> 16) & 0xFF, (lowBits >>> 8) & 0xFF, lowBits & 0xFF
        );
        const words = [];
        for (let i = 0; i < inputStr.length; i += 4) {
            words.push((inputStr.charCodeAt(i) << 24) | (inputStr.charCodeAt(i + 1) << 16) | (inputStr.charCodeAt(i + 2) << 8) | inputStr.charCodeAt(i + 3));
        }
        for (let i = 0; i < words.length; i += 16) {
            const w = new Array(64);
            for (let j = 0; j < 16; j++) {
                w[j] = words[i + j];
            }
            for (let j = 16; j < 64; j++) {
                const s0 = rotateRight(w[j - 15], 7) ^ rotateRight(w[j - 15], 18) ^ (w[j - 15] >>> 3);
                const s1 = rotateRight(w[j - 2], 17) ^ rotateRight(w[j - 2], 19) ^ (w[j - 2] >>> 10);
                w[j] = (w[j - 16] + s0 + w[j - 7] + s1) >>> 0;
            }
            let [a, b, c, d, e, f, g, h] = hState;
            for (let j = 0; j < 64; j++) {
                const S1 = rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25);
                const ch = (e & f) ^ (~e & g);
                const temp1 = (h + S1 + ch + kConstants[j] + w[j]) >>> 0;
                const S0 = rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22);
                const maj = (a & b) ^ (a & c) ^ (b & c);
                const temp2 = (S0 + maj) >>> 0;
                h = g;
                g = f;
                f = e;
                e = (d + temp1) >>> 0;
                d = c;
                c = b;
                b = a;
                a = (temp1 + temp2) >>> 0;
            }
            hState[0] = (hState[0] + a) >>> 0;
            hState[1] = (hState[1] + b) >>> 0;
            hState[2] = (hState[2] + c) >>> 0;
            hState[3] = (hState[3] + d) >>> 0;
            hState[4] = (hState[4] + e) >>> 0;
            hState[5] = (hState[5] + f) >>> 0;
            hState[6] = (hState[6] + g) >>> 0;
            hState[7] = (hState[7] + h) >>> 0;
        }
        return hState.slice(0, 7);
    };
    const rotateRight = (value, shift) => {return ((value >>> shift) | (value << (32 - shift))) >>> 0};
    const utf8Message = toUtf8(message);
    const hashWords = computeHash(utf8Message);
    return bytesToHex(hashWords.flatMap(h => [(h >>> 24) & 0xFF, (h >>> 16) & 0xFF, (h >>> 8) & 0xFF, h & 0xFF]));
}

// 解析代理路径配置
function 解析代理路径(路径) {
  const proxyMatch = 路径.match(/\/(socks5|http):\/\/([^\/\?&]+)/);
  return proxyMatch ? {
    类型: proxyMatch[1],
    账号: [decodeURIComponent(proxyMatch[2])]
  } : { 类型: 'direct' };
}

// Base64解码函数
function base64Decode(str) {
  const base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  const padded = base64 + '='.repeat((4 - base64.length % 4) % 4);
  return atob(padded);
}

async function 启动传输管道(WS接口, 代理配置) {
  let TCP接口, 首包数据 = false, 首包处理完成, 传输数据, 读取数据, 传输队列 = Promise.resolve();
  
  try {
    WS接口.addEventListener('message', async event => {
      if (!首包数据) {
        首包数据 = true;
        首包处理完成 = 解析首包数据(event.data);
        传输队列 = 传输队列.then(() => 首包处理完成).catch();
      } else {
        await 首包处理完成;
        传输队列 = 传输队列.then(async () => await 传输数据.write(event.data)).catch();
      }
    });
    
    async function 解析首包数据(首包数据) {
      const 二进制数据 = new Uint8Array(首包数据);
      
      // 计算预期的SHA224哈希值
      const 预期哈希 = sha224Hash(trojan密码);
      const 预期哈希字节 = new TextEncoder().encode(预期哈希);
      
      // 验证前56字节的哈希值
      for (let i = 0; i < 56; i++) {
        if (二进制数据[i] !== 预期哈希字节[i]) {
          throw new Error('Trojan密码验证失败');
        }
      }
      
      // 跳过CRLF (0x0d 0x0a)
      let 索引 = 58;
      if (二进制数据[索引++] !== 1) throw new Error('无效的命令');
      
      // 解析地址类型
      const 地址类型 = 二进制数据[索引++];
      let 访问地址, 地址长度;
      
      switch (地址类型) {
        case 1: // IPv4
          地址长度 = 4;
          访问地址 = 二进制数据.slice(索引, 索引 + 地址长度).join('.');
          break;
        case 3: // 域名
          地址长度 = 二进制数据[索引++];
          访问地址 = new TextDecoder().decode(二进制数据.slice(索引, 索引 + 地址长度));
          break;
        case 4: // IPv6
          地址长度 = 16;
          const view = new DataView(二进制数据.buffer, 索引, 16);
          const parts = [];
          for (let i = 0; i < 8; i++) {
            parts.push(view.getUint16(i * 2).toString(16));
          }
          访问地址 = parts.join(':');
          break;
        default:
          throw new Error('无效的地址类型');
      }
      
      索引 += 地址长度;
      
      // 解析端口
      const 访问端口 = new DataView(二进制数据.buffer, 索引, 2).getUint16(0);
      索引 += 2;
      
      // DNS查询处理
      if (访问端口 === 53) {
        const DNS查询 = 二进制数据.slice(索引);
        const DOH结果 = await (await fetch('https://dns.google/dns-query', {
          method: 'POST', 
          headers: { 'content-type': 'application/dns-message' }, 
          body: DNS查询
        })).arrayBuffer();
        const 长度头部 = new Uint8Array([(DOH结果.byteLength >> 8) & 0xff, DOH结果.byteLength & 0xff]);
        WS接口.send(await new Blob([长度头部, DOH结果]).arrayBuffer());
        return;
      }
      
      // 建立连接
      TCP接口 = await 创建代理连接(代理配置, 地址类型, 访问地址, 访问端口);
      await TCP接口.opened;
      传输数据 = TCP接口.writable.getWriter();
      读取数据 = TCP接口.readable.getReader();
      
      // 发送初始数据（跳过CRLF部分）
      const CRLF索引 = 索引 + 2; // 跳过 0x0d 0x0a
      const 初始数据 = 二进制数据.slice(CRLF索引);
      if (初始数据.length) await 传输数据.write(初始数据);
      启动回传管道();
    }
    
    async function 启动回传管道() {
      while (true) {
        const { done, value } = await 读取数据.read();
        if (value?.length > 0) 传输队列 = 传输队列.then(() => WS接口.send(value)).catch();
        if (done) break;
      }
    }
  } catch (e) {
    console.error('传输管道错误:', e);
    WS接口.close();
  }
}

async function 创建代理连接(代理配置, 地址类型, 访问地址, 访问端口) {
  if (代理配置.类型 === 'direct') {
    const hostname = 地址类型 === 4 ? `[${访问地址}]` : 访问地址;
    return (await import('cloudflare:sockets')).connect({ hostname, port: 访问端口 });
  }
  
  for (const 账号字符串 of 代理配置.账号) {
    try {
      const { 账号, 密码, 地址, 端口 } = 解析代理账号(账号字符串);
      const socket = (await import('cloudflare:sockets')).connect({ hostname: 地址, port: 端口 });
      await socket.opened;
      
      if (代理配置.类型 === 'socks5') {
        await 建立SOCKS5连接(socket, 账号, 密码, 地址类型, 访问地址, 访问端口);
      } else {
        await 建立HTTP连接(socket, 账号, 密码, 地址类型, 访问地址, 访问端口);
      }
      
      return socket;
    } catch (error) {
      console.error(`${代理配置.类型}代理连接失败:`, error);
    }
  }
  throw new Error(`所有${代理配置.类型}代理失效`);
}

async function 建立SOCKS5连接(socket, 账号, 密码, 地址类型, 访问地址, 访问端口) {
  const writer = socket.writable.getWriter();
  const reader = socket.readable.getReader();
  const encoder = new TextEncoder();
  
  try {
    // 认证协商
    await writer.write(new Uint8Array([5, 2, 0, 2]));
    const authResponse = (await reader.read()).value;
    
    if (authResponse[1] === 0x02) {
      if (!账号 || !密码) throw new Error('未配置账号密码');
      await writer.write(new Uint8Array([1, 账号.length, ...encoder.encode(账号), 密码.length, ...encoder.encode(密码)]));
      const authResult = (await reader.read()).value;
      if (authResult[0] !== 0x01 || authResult[1] !== 0x00) throw new Error('账号密码错误');
    }
    
    // 构建连接请求
    let 地址数据;
    switch (地址类型) {
      case 1: 地址数据 = new Uint8Array([1, ...访问地址.split('.').map(Number)]); break;
      case 3: 地址数据 = new Uint8Array([3, 访问地址.length, ...encoder.encode(访问地址)]); break;
      case 4: 地址数据 = 构建IPv6地址(访问地址); break;
    }
    
    await writer.write(new Uint8Array([5, 1, 0, ...地址数据, 访问端口 >> 8, 访问端口 & 0xff]));
    const connectResponse = (await reader.read()).value;
    
    if (connectResponse[0] !== 0x05 || connectResponse[1] !== 0x00) {
      throw new Error(`连接失败: ${访问地址}:${访问端口}`);
    }
  } finally {
    writer.releaseLock();
    reader.releaseLock();
  }
}

async function 建立HTTP连接(socket, 账号, 密码, 地址类型, 访问地址, 访问端口) {
  const writer = socket.writable.getWriter();
  const reader = socket.readable.getReader();
  
  try {
    const 目标地址 = 地址类型 === 4 ? `[${访问地址}]:${访问端口}` : `${访问地址}:${访问端口}`;
    let HTTP请求 = `CONNECT ${目标地址} HTTP/1.1\r\nHost: ${目标地址}\r\n`;
    
    if (账号 || 密码) {
      HTTP请求 += `Proxy-Authorization: Basic ${btoa(`${账号}:${密码}`)}\r\n`;
    }
    
    await writer.write(new TextEncoder().encode(HTTP请求 + '\r\n'));
    
    let 响应 = '', decoder = new TextDecoder();
    while (true) {
      const { done, value } = await reader.read();
      if (done) throw new Error('连接中断');
      响应 += decoder.decode(value, { stream: true });
      if (响应.includes('\r\n\r\n')) break;
    }
    
    const 状态码 = 响应.match(/HTTP\/1\.[01]\s+(\d+)/)?.[1];
    if (状态码 !== '200') throw new Error(`连接失败: ${响应.split('\r\n')[0]}`);
  } finally {
    writer.releaseLock();
    reader.releaseLock();
  }
}

function 构建IPv6地址(地址) {
  const 去括号 = 地址.replace(/^\[|\]$/g, '');
  const 分段 = 去括号.split('::');
  const 前缀 = 分段[0] ? 分段[0].split(':').filter(Boolean) : [];
  const 后缀 = 分段[1] ? 分段[1].split(':').filter(Boolean) : [];
  const 完整分段 = [...前缀, ...Array(8 - 前缀.length - 后缀.length).fill('0'), ...后缀];
  const IPv6字节 = 完整分段.flatMap(段 => { const v = parseInt(段 || '0', 16); return [v >> 8, v & 0xff]; });
  return new Uint8Array([0x04, ...IPv6字节]);
}

function 解析代理账号(代理字符串) {
  const atIndex = 代理字符串.lastIndexOf("@");
  const 账号段 = 代理字符串.slice(0, atIndex);
  const 地址段 = 代理字符串.slice(atIndex + 1);
  
  let 账号 = '', 密码 = '';
  if (atIndex !== -1 && 账号段) {
    try {
      const 解码 = base64Decode(账号段);
      const colonIndex = 解码.indexOf(":");
      账号 = colonIndex !== -1 ? 解码.slice(0, colonIndex) : 解码;
      密码 = colonIndex !== -1 ? 解码.slice(colonIndex + 1) : '';
    } catch {
      const colonIndex = 账号段.lastIndexOf(":");
      账号 = colonIndex !== -1 ? 账号段.slice(0, colonIndex) : 账号段;
      密码 = colonIndex !== -1 ? 账号段.slice(colonIndex + 1) : '';
    }
  }
  
  const [地址, 端口 = 443] = 地址段.includes('[') ? 
    [地址段.slice(0, 地址段.lastIndexOf(']') + 1), 地址段.split(']:')[1]] :
    地址段.split(':');
    
  return { 账号, 密码, 地址, 端口: parseInt(端口) };
}

export default {
  async fetch(访问请求, env, ctx) {
    try {
      if (访问请求.headers.get('Upgrade') === 'websocket') {
        const 路径 = 访问请求.url.replace(/^https?:\/\/[^/]+/, '');
        const 代理配置 = 解析代理路径(路径);
        const [客户端, WS接口] = Object.values(new WebSocketPair());
        
        WS接口.accept();
        ctx.waitUntil(启动传输管道(WS接口, 代理配置));
        
        return new Response(null, { 
          status: 101, 
          webSocket: 客户端,
          headers: { 'Upgrade': 'websocket', 'Connection': 'Upgrade' }
        });
      }
      
      return new Response('Hello World', { 
        headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-cache' }
      });
    } catch (error) {
      return new Response(`Worker Error: ${error.message}`, { 
        status: 500,
        headers: { 'Content-Type': 'text/plain; charset=utf-8' }
      });
    }
  }
};